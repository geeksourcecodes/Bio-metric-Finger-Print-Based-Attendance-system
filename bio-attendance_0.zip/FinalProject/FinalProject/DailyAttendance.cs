﻿namespace FinalProject {
    
    
    public partial class DailyAttendance {
    }
}
