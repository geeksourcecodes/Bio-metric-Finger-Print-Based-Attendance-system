﻿namespace FinalProject
{
    partial class TimeSheet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TimeSheet));
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBoxCnic = new System.Windows.Forms.TextBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.semester = new System.Windows.Forms.Label();
            this.year = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Mon = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Wed = new System.Windows.Forms.Label();
            this.Tues = new System.Windows.Forms.Label();
            this.Thu = new System.Windows.Forms.Label();
            this.Fri = new System.Windows.Forms.Label();
            this.Sat = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.MonIn = new System.Windows.Forms.ComboBox();
            this.TuesIn = new System.Windows.Forms.ComboBox();
            this.WedIn = new System.Windows.Forms.ComboBox();
            this.ThuIn = new System.Windows.Forms.ComboBox();
            this.FriIn = new System.Windows.Forms.ComboBox();
            this.SatIn = new System.Windows.Forms.ComboBox();
            this.MonOut = new System.Windows.Forms.ComboBox();
            this.TuesOut = new System.Windows.Forms.ComboBox();
            this.WedOut = new System.Windows.Forms.ComboBox();
            this.ThuOut = new System.Windows.Forms.ComboBox();
            this.FriOut = new System.Windows.Forms.ComboBox();
            this.SatOut = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.dataGridViewEmployee = new System.Windows.Forms.DataGridView();
            this.pictureBoxPicture = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBoxControl = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Day3 = new System.Windows.Forms.Label();
            this.Day6 = new System.Windows.Forms.Label();
            this.Day2 = new System.Windows.Forms.Label();
            this.Day5 = new System.Windows.Forms.Label();
            this.Day1 = new System.Windows.Forms.Label();
            this.Day4 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPicture)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.textBoxCnic);
            this.panel2.Controls.Add(this.textBoxName);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.semester);
            this.panel2.Controls.Add(this.year);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(6, 76);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(336, 104);
            this.panel2.TabIndex = 1;
            // 
            // textBoxCnic
            // 
            this.textBoxCnic.BackColor = System.Drawing.Color.Black;
            this.textBoxCnic.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCnic.ForeColor = System.Drawing.Color.White;
            this.textBoxCnic.Location = new System.Drawing.Point(124, 70);
            this.textBoxCnic.Name = "textBoxCnic";
            this.textBoxCnic.ReadOnly = true;
            this.textBoxCnic.Size = new System.Drawing.Size(152, 22);
            this.textBoxCnic.TabIndex = 2;
            this.textBoxCnic.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBoxName
            // 
            this.textBoxName.BackColor = System.Drawing.Color.Black;
            this.textBoxName.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxName.ForeColor = System.Drawing.Color.White;
            this.textBoxName.Location = new System.Drawing.Point(124, 38);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.ReadOnly = true;
            this.textBoxName.Size = new System.Drawing.Size(152, 22);
            this.textBoxName.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(282, 37);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(37, 55);
            this.button1.TabIndex = 1;
            this.button1.Text = "<";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(7, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 19);
            this.label3.TabIndex = 0;
            this.label3.Text = "Employee CNIC";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(7, 37);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(110, 19);
            this.label11.TabIndex = 0;
            this.label11.Text = "Employee Name";
            // 
            // semester
            // 
            this.semester.AutoSize = true;
            this.semester.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.semester.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.semester.Location = new System.Drawing.Point(277, 7);
            this.semester.Name = "semester";
            this.semester.Size = new System.Drawing.Size(54, 15);
            this.semester.TabIndex = 0;
            this.semester.Text = "semester";
            // 
            // year
            // 
            this.year.AutoSize = true;
            this.year.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.year.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.year.Location = new System.Drawing.Point(115, 7);
            this.year.Name = "year";
            this.year.Size = new System.Drawing.Size(34, 17);
            this.year.TabIndex = 0;
            this.year.Text = "year";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(206, 7);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 17);
            this.label15.TabIndex = 0;
            this.label15.Text = "Semester";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Academic year";
            // 
            // Mon
            // 
            this.Mon.AutoSize = true;
            this.Mon.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mon.Location = new System.Drawing.Point(9, 219);
            this.Mon.Name = "Mon";
            this.Mon.Size = new System.Drawing.Size(60, 19);
            this.Mon.TabIndex = 2;
            this.Mon.Text = "Monday";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(9, 189);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 19);
            this.label5.TabIndex = 3;
            this.label5.Text = "Working Days";
            // 
            // Wed
            // 
            this.Wed.AutoSize = true;
            this.Wed.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Wed.Location = new System.Drawing.Point(9, 277);
            this.Wed.Name = "Wed";
            this.Wed.Size = new System.Drawing.Size(84, 19);
            this.Wed.TabIndex = 4;
            this.Wed.Text = "Wednesday ";
            // 
            // Tues
            // 
            this.Tues.AutoSize = true;
            this.Tues.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tues.Location = new System.Drawing.Point(9, 248);
            this.Tues.Name = "Tues";
            this.Tues.Size = new System.Drawing.Size(59, 19);
            this.Tues.TabIndex = 5;
            this.Tues.Text = "Tuesday";
            // 
            // Thu
            // 
            this.Thu.AutoSize = true;
            this.Thu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Thu.Location = new System.Drawing.Point(9, 306);
            this.Thu.Name = "Thu";
            this.Thu.Size = new System.Drawing.Size(65, 19);
            this.Thu.TabIndex = 3;
            this.Thu.Text = "Thursday";
            this.Thu.Click += new System.EventHandler(this.label8_Click);
            // 
            // Fri
            // 
            this.Fri.AutoSize = true;
            this.Fri.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Fri.Location = new System.Drawing.Point(9, 334);
            this.Fri.Name = "Fri";
            this.Fri.Size = new System.Drawing.Size(48, 19);
            this.Fri.TabIndex = 2;
            this.Fri.Text = "Friday";
            this.Fri.Click += new System.EventHandler(this.label9_Click);
            // 
            // Sat
            // 
            this.Sat.AutoSize = true;
            this.Sat.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sat.Location = new System.Drawing.Point(9, 365);
            this.Sat.Name = "Sat";
            this.Sat.Size = new System.Drawing.Size(63, 19);
            this.Sat.TabIndex = 5;
            this.Sat.Text = "Saturday";
            this.Sat.Click += new System.EventHandler(this.label10_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(132, 189);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 19);
            this.label12.TabIndex = 6;
            this.label12.Text = "Time In";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(248, 189);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 19);
            this.label13.TabIndex = 7;
            this.label13.Text = "Time Out";
            // 
            // MonIn
            // 
            this.MonIn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MonIn.FormattingEnabled = true;
            this.MonIn.Items.AddRange(new object[] {
            "",
            "08:00",
            "09:00",
            "10:00",
            "11:00",
            "12:00",
            "13:00",
            "14:00",
            "15:00",
            "16:00",
            "17:00",
            "18:00",
            "19:00",
            "20:00"});
            this.MonIn.Location = new System.Drawing.Point(120, 217);
            this.MonIn.Name = "MonIn";
            this.MonIn.Size = new System.Drawing.Size(90, 21);
            this.MonIn.TabIndex = 8;
            this.MonIn.SelectedIndexChanged += new System.EventHandler(this.MonIn_SelectedIndexChanged);
            // 
            // TuesIn
            // 
            this.TuesIn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TuesIn.FormattingEnabled = true;
            this.TuesIn.Items.AddRange(new object[] {
            "",
            "08:00",
            "09:00",
            "10:00",
            "11:00",
            "12:00",
            "13:00",
            "14:00",
            "15:00",
            "16:00",
            "17:00",
            "18:00",
            "19:00",
            "20:00"});
            this.TuesIn.Location = new System.Drawing.Point(120, 246);
            this.TuesIn.Name = "TuesIn";
            this.TuesIn.Size = new System.Drawing.Size(90, 21);
            this.TuesIn.TabIndex = 9;
            this.TuesIn.SelectedIndexChanged += new System.EventHandler(this.TuesIn_SelectedIndexChanged);
            // 
            // WedIn
            // 
            this.WedIn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.WedIn.FormattingEnabled = true;
            this.WedIn.Items.AddRange(new object[] {
            "",
            "08:00",
            "09:00",
            "10:00",
            "11:00",
            "12:00",
            "13:00",
            "14:00",
            "15:00",
            "16:00",
            "17:00",
            "18:00",
            "19:00",
            "20:00"});
            this.WedIn.Location = new System.Drawing.Point(120, 275);
            this.WedIn.Name = "WedIn";
            this.WedIn.Size = new System.Drawing.Size(90, 21);
            this.WedIn.TabIndex = 8;
            this.WedIn.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // ThuIn
            // 
            this.ThuIn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ThuIn.FormattingEnabled = true;
            this.ThuIn.Items.AddRange(new object[] {
            "",
            "08:00",
            "09:00",
            "10:00",
            "11:00",
            "12:00",
            "13:00",
            "14:00",
            "15:00",
            "16:00",
            "17:00",
            "18:00",
            "19:00",
            "20:00"});
            this.ThuIn.Location = new System.Drawing.Point(120, 304);
            this.ThuIn.Name = "ThuIn";
            this.ThuIn.Size = new System.Drawing.Size(90, 21);
            this.ThuIn.TabIndex = 9;
            this.ThuIn.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // FriIn
            // 
            this.FriIn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FriIn.FormattingEnabled = true;
            this.FriIn.Items.AddRange(new object[] {
            "",
            "08:00",
            "09:00",
            "10:00",
            "11:00",
            "12:00",
            "13:00",
            "14:00",
            "15:00",
            "16:00",
            "17:00",
            "18:00",
            "19:00",
            "20:00"});
            this.FriIn.Location = new System.Drawing.Point(120, 334);
            this.FriIn.Name = "FriIn";
            this.FriIn.Size = new System.Drawing.Size(90, 21);
            this.FriIn.TabIndex = 8;
            this.FriIn.SelectedIndexChanged += new System.EventHandler(this.comboBox5_SelectedIndexChanged);
            // 
            // SatIn
            // 
            this.SatIn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SatIn.FormattingEnabled = true;
            this.SatIn.Items.AddRange(new object[] {
            "",
            "08:00",
            "09:00",
            "10:00",
            "11:00",
            "12:00",
            "13:00",
            "14:00",
            "15:00",
            "16:00",
            "17:00",
            "18:00",
            "19:00",
            "20:00"});
            this.SatIn.Location = new System.Drawing.Point(120, 363);
            this.SatIn.Name = "SatIn";
            this.SatIn.Size = new System.Drawing.Size(90, 21);
            this.SatIn.TabIndex = 9;
            this.SatIn.SelectedIndexChanged += new System.EventHandler(this.comboBox6_SelectedIndexChanged);
            // 
            // MonOut
            // 
            this.MonOut.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MonOut.FormattingEnabled = true;
            this.MonOut.Items.AddRange(new object[] {
            "",
            "08:00",
            "09:00",
            "10:00",
            "11:00",
            "12:00",
            "13:00",
            "14:00",
            "15:00",
            "16:00",
            "17:00",
            "18:00",
            "19:00",
            "20:00"});
            this.MonOut.Location = new System.Drawing.Point(236, 220);
            this.MonOut.Name = "MonOut";
            this.MonOut.Size = new System.Drawing.Size(90, 21);
            this.MonOut.TabIndex = 8;
            this.MonOut.SelectedIndexChanged += new System.EventHandler(this.MonOut_SelectedIndexChanged);
            this.MonOut.Leave += new System.EventHandler(this.comboBox7_Leave);
            // 
            // TuesOut
            // 
            this.TuesOut.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TuesOut.FormattingEnabled = true;
            this.TuesOut.Items.AddRange(new object[] {
            "",
            "08:00",
            "09:00",
            "10:00",
            "11:00",
            "12:00",
            "13:00",
            "14:00",
            "15:00",
            "16:00",
            "17:00",
            "18:00",
            "19:00",
            "20:00"});
            this.TuesOut.Location = new System.Drawing.Point(236, 249);
            this.TuesOut.Name = "TuesOut";
            this.TuesOut.Size = new System.Drawing.Size(90, 21);
            this.TuesOut.TabIndex = 9;
            this.TuesOut.Visible = false;
            this.TuesOut.Leave += new System.EventHandler(this.TuesOut_Leave);
            // 
            // WedOut
            // 
            this.WedOut.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.WedOut.FormattingEnabled = true;
            this.WedOut.Items.AddRange(new object[] {
            "",
            "08:00",
            "09:00",
            "10:00",
            "11:00",
            "12:00",
            "13:00",
            "14:00",
            "15:00",
            "16:00",
            "17:00",
            "18:00",
            "19:00",
            "20:00"});
            this.WedOut.Location = new System.Drawing.Point(236, 278);
            this.WedOut.Name = "WedOut";
            this.WedOut.Size = new System.Drawing.Size(90, 21);
            this.WedOut.TabIndex = 8;
            this.WedOut.Visible = false;
            this.WedOut.SelectedIndexChanged += new System.EventHandler(this.comboBox9_SelectedIndexChanged);
            this.WedOut.Leave += new System.EventHandler(this.WedOut_Leave);
            // 
            // ThuOut
            // 
            this.ThuOut.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ThuOut.FormattingEnabled = true;
            this.ThuOut.Items.AddRange(new object[] {
            "",
            "08:00",
            "09:00",
            "10:00",
            "11:00",
            "12:00",
            "13:00",
            "14:00",
            "15:00",
            "16:00",
            "17:00",
            "18:00",
            "19:00",
            "20:00"});
            this.ThuOut.Location = new System.Drawing.Point(236, 307);
            this.ThuOut.Name = "ThuOut";
            this.ThuOut.Size = new System.Drawing.Size(90, 21);
            this.ThuOut.TabIndex = 9;
            this.ThuOut.Visible = false;
            this.ThuOut.SelectedIndexChanged += new System.EventHandler(this.comboBox10_SelectedIndexChanged);
            this.ThuOut.Leave += new System.EventHandler(this.ThuOut_Leave);
            // 
            // FriOut
            // 
            this.FriOut.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FriOut.FormattingEnabled = true;
            this.FriOut.Items.AddRange(new object[] {
            "",
            "08:00",
            "09:00",
            "10:00",
            "11:00",
            "12:00",
            "13:00",
            "14:00",
            "15:00",
            "16:00",
            "17:00",
            "18:00",
            "19:00",
            "20:00"});
            this.FriOut.Location = new System.Drawing.Point(236, 337);
            this.FriOut.Name = "FriOut";
            this.FriOut.Size = new System.Drawing.Size(90, 21);
            this.FriOut.TabIndex = 8;
            this.FriOut.Visible = false;
            this.FriOut.SelectedIndexChanged += new System.EventHandler(this.comboBox11_SelectedIndexChanged);
            this.FriOut.Leave += new System.EventHandler(this.FriOut_Leave);
            // 
            // SatOut
            // 
            this.SatOut.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SatOut.FormattingEnabled = true;
            this.SatOut.Items.AddRange(new object[] {
            "",
            "08:00",
            "09:00",
            "10:00",
            "11:00",
            "12:00",
            "13:00",
            "14:00",
            "15:00",
            "16:00",
            "17:00",
            "18:00",
            "19:00",
            "20:00"});
            this.SatOut.Location = new System.Drawing.Point(236, 366);
            this.SatOut.Name = "SatOut";
            this.SatOut.Size = new System.Drawing.Size(90, 21);
            this.SatOut.TabIndex = 9;
            this.SatOut.Visible = false;
            this.SatOut.SelectedIndexChanged += new System.EventHandler(this.comboBox12_SelectedIndexChanged);
            this.SatOut.Leave += new System.EventHandler(this.SatOut_Leave);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(348, 223);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(120, 164);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.CornflowerBlue;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(11, 128);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(99, 30);
            this.button5.TabIndex = 20;
            this.button5.Text = "View All";
            this.button5.UseCompatibleTextRendering = true;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.CornflowerBlue;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(11, 91);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(99, 30);
            this.button4.TabIndex = 20;
            this.button4.Text = "Delete";
            this.button4.UseCompatibleTextRendering = true;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.CornflowerBlue;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(11, 53);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(99, 30);
            this.button2.TabIndex = 19;
            this.button2.Text = "Update";
            this.button2.UseCompatibleTextRendering = true;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.CornflowerBlue;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(11, 15);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(99, 30);
            this.button3.TabIndex = 17;
            this.button3.Text = "Saved";
            this.button3.UseCompatibleTextRendering = true;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dataGridViewEmployee
            // 
            this.dataGridViewEmployee.AllowUserToAddRows = false;
            this.dataGridViewEmployee.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridViewEmployee.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            this.dataGridViewEmployee.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewEmployee.ColumnHeadersHeight = 25;
            this.dataGridViewEmployee.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridViewEmployee.Location = new System.Drawing.Point(7, 396);
            this.dataGridViewEmployee.Name = "dataGridViewEmployee";
            this.dataGridViewEmployee.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridViewEmployee.RowHeadersWidth = 25;
            this.dataGridViewEmployee.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewEmployee.Size = new System.Drawing.Size(468, 114);
            this.dataGridViewEmployee.TabIndex = 27;
            this.dataGridViewEmployee.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewEmployee_RowHeaderMouseClick);
            // 
            // pictureBoxPicture
            // 
            this.pictureBoxPicture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxPicture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPicture.Location = new System.Drawing.Point(348, 76);
            this.pictureBoxPicture.Name = "pictureBoxPicture";
            this.pictureBoxPicture.Size = new System.Drawing.Size(126, 146);
            this.pictureBoxPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxPicture.TabIndex = 26;
            this.pictureBoxPicture.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BackgroundImage = global::FinalProject.Properties.Resources.penal;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.textBoxControl);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(482, 71);
            this.panel1.TabIndex = 0;
            // 
            // textBoxControl
            // 
            this.textBoxControl.Location = new System.Drawing.Point(0, 0);
            this.textBoxControl.Name = "textBoxControl";
            this.textBoxControl.Size = new System.Drawing.Size(100, 20);
            this.textBoxControl.TabIndex = 1;
            this.textBoxControl.Visible = false;
            this.textBoxControl.TextChanged += new System.EventHandler(this.textBoxControl_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(71, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(323, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Define Employee TimeTable";
            // 
            // Day3
            // 
            this.Day3.AutoSize = true;
            this.Day3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Day3.Location = new System.Drawing.Point(88, 276);
            this.Day3.Name = "Day3";
            this.Day3.Size = new System.Drawing.Size(17, 19);
            this.Day3.TabIndex = 31;
            this.Day3.Text = "3";
            this.Day3.Visible = false;
            // 
            // Day6
            // 
            this.Day6.AutoSize = true;
            this.Day6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Day6.Location = new System.Drawing.Point(88, 362);
            this.Day6.Name = "Day6";
            this.Day6.Size = new System.Drawing.Size(17, 19);
            this.Day6.TabIndex = 32;
            this.Day6.Text = "6";
            this.Day6.Visible = false;
            // 
            // Day2
            // 
            this.Day2.AutoSize = true;
            this.Day2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Day2.Location = new System.Drawing.Point(88, 245);
            this.Day2.Name = "Day2";
            this.Day2.Size = new System.Drawing.Size(17, 19);
            this.Day2.TabIndex = 33;
            this.Day2.Text = "2";
            this.Day2.Visible = false;
            // 
            // Day5
            // 
            this.Day5.AutoSize = true;
            this.Day5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Day5.Location = new System.Drawing.Point(88, 333);
            this.Day5.Name = "Day5";
            this.Day5.Size = new System.Drawing.Size(17, 19);
            this.Day5.TabIndex = 28;
            this.Day5.Text = "5";
            this.Day5.Visible = false;
            // 
            // Day1
            // 
            this.Day1.AutoSize = true;
            this.Day1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Day1.Location = new System.Drawing.Point(88, 216);
            this.Day1.Name = "Day1";
            this.Day1.Size = new System.Drawing.Size(17, 19);
            this.Day1.TabIndex = 29;
            this.Day1.Text = "1";
            this.Day1.Visible = false;
            // 
            // Day4
            // 
            this.Day4.AutoSize = true;
            this.Day4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Day4.Location = new System.Drawing.Point(88, 304);
            this.Day4.Name = "Day4";
            this.Day4.Size = new System.Drawing.Size(17, 19);
            this.Day4.TabIndex = 30;
            this.Day4.Text = "4";
            this.Day4.Visible = false;
            // 
            // TimeSheet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(483, 514);
            this.Controls.Add(this.Day3);
            this.Controls.Add(this.Day6);
            this.Controls.Add(this.Day2);
            this.Controls.Add(this.Day5);
            this.Controls.Add(this.Day1);
            this.Controls.Add(this.Day4);
            this.Controls.Add(this.dataGridViewEmployee);
            this.Controls.Add(this.pictureBoxPicture);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.SatOut);
            this.Controls.Add(this.SatIn);
            this.Controls.Add(this.FriOut);
            this.Controls.Add(this.FriIn);
            this.Controls.Add(this.ThuOut);
            this.Controls.Add(this.ThuIn);
            this.Controls.Add(this.WedOut);
            this.Controls.Add(this.WedIn);
            this.Controls.Add(this.TuesOut);
            this.Controls.Add(this.TuesIn);
            this.Controls.Add(this.MonOut);
            this.Controls.Add(this.MonIn);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.Wed);
            this.Controls.Add(this.Sat);
            this.Controls.Add(this.Tues);
            this.Controls.Add(this.Fri);
            this.Controls.Add(this.Mon);
            this.Controls.Add(this.Thu);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "TimeSheet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee Time Table";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TimeSheet_FormClosing);
            this.Load += new System.EventHandler(this.TimeSheet_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPicture)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button5;
        public System.Windows.Forms.TextBox textBoxCnic;
        public System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.PictureBox pictureBoxPicture;
        public System.Windows.Forms.ComboBox MonIn;
        public System.Windows.Forms.ComboBox TuesIn;
        public System.Windows.Forms.ComboBox ThuIn;
        public System.Windows.Forms.ComboBox FriIn;
        public System.Windows.Forms.ComboBox SatIn;
        public System.Windows.Forms.ComboBox MonOut;
        public System.Windows.Forms.ComboBox TuesOut;
        public System.Windows.Forms.ComboBox WedOut;
        public System.Windows.Forms.ComboBox ThuOut;
        public System.Windows.Forms.ComboBox FriOut;
        public System.Windows.Forms.ComboBox SatOut;
        public System.Windows.Forms.Label Mon;
        public System.Windows.Forms.Label Wed;
        public System.Windows.Forms.Label Tues;
        public System.Windows.Forms.Label Thu;
        public System.Windows.Forms.Label Fri;
        public System.Windows.Forms.Label Sat;
        public System.Windows.Forms.Label semester;
        public System.Windows.Forms.Label year;
        public System.Windows.Forms.ComboBox WedIn;
        private System.Windows.Forms.TextBox textBoxControl;
        private System.Windows.Forms.DataGridView dataGridViewEmployee;
        public System.Windows.Forms.Label Day3;
        public System.Windows.Forms.Label Day6;
        public System.Windows.Forms.Label Day2;
        public System.Windows.Forms.Label Day5;
        public System.Windows.Forms.Label Day1;
        public System.Windows.Forms.Label Day4;
    }
}